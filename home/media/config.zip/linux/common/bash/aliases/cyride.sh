alias cy.23='evince $cyride_dir/23_orange.pdf'
alias cy.orange=cy.23
alias cy.6s='evince $cyride_dir/6s_brown.pdf'
alias cy.brown.s=cy.6s
alias cy.6n='evince $cyride_dir/6n_brown.pdf'
alias cy.brown.n=cy.6n
