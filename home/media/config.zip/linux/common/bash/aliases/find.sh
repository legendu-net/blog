
# find files ending with ~
alias find.tilde='find . -name "*~"'
alias find.swp='find . -name "*.swp"'
alias find.sync='find . -name "*.!sync"'
alias find.rhistory='find . -iname "*.rhistory"'


