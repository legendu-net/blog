# git
alias git.c='git commit'
alias git.ac='git commit -a'
alias git.acp='git commit -a -m ... && git push'
alias git.modified="git status | grep 'modified' | sed 's/^#.*modified://'"
alias git.deleted="git status | grep 'deleted' | sed 's/^#.*modified://'"
alias git.renamed="git status | grep 'renamed' | sed 's/^#.*modified://'"
alias git.stat='git status'
alias git.commit='git commit -m'
