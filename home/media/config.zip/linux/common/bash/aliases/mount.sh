
# sshfs
alias sshfs.linux11='sshfs.server $(whoami)@$linux11 323'
alias sshfs.linux10='sshfs.server $(whoami)@$linux10 323'
alias sshfs.y570='sshfs.server $(whoami)@$y570 323'
alias sshfs.home='sshfs.server $(whoami)@$homeip 323'
alias sshfs.toshiba='sshfs.server $(whoami)@$toshiba 323'
alias sshfs.econ3='sshfs.server lisa1107@$economics3 323'
alias sshfs.s07='sshfs.server lisa1107@$student07 323'
alias sshfs.s08='sshfs.server lisa1107@$student08 323'
# mount
alias mount.ntfs.sdb1='sudo mount -o uid=$(whoami),gid=$(whoami),fmask=0137,dmask=0027 /dev/sdb1'
alias mount.sdb1='sudo mount -o uid=$(whoami),gid=$(whoami) /dev/sdb1'
alias umount.sdb1='sudo umount /dev/sdb1'
alias mount.ntfs.sdc1='sudo mount -o uid=$(whoami),gid=$(whoami),fmask=0137,dmask=0027 /dev/sdc1'
alias mount.sdc1='sudo mount -o uid=$(whoami),gid=$(whoami) /dev/sdc1'
alias umount.sdc1='sudo umount /dev/sdc1'
alias mount.vboxsf='sudo mount -t vboxsf -o uid=$(whoami),gid=$(whoami)'
alias mount.vboxsf.hh='sudo mount -t vboxsf -o uid=$(whoami),gid=$(whoami) host_home'
alias mount.cd="sudo mount -t iso9660 -o ro /dev/cdrom"
