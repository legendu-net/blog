
# processes
alias top.xorg='top | grep -i xorg'
alias top.chrome='top | grep -i chrome'
alias ps.running='ps ax | grep -i'
alias ps.xorg='ps ax | grep -i xorg'
alias ps.chrome='ps ax | grep -i chrome'
