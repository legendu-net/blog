# rdesktop
alias rdesktop.sas='rdesktop sas.stat.iastate.edu -g 100% -u $(whoami) -r disk:dclong=/home/$(whoami)'
alias rdesktop.gs='rdesktop gs.stat.iastate.edu -g 100% -u $(whoami) -r disk:dclong=/home/$(whoami)'
alias rdesktop.econ='rdesktop student.econ.iastate.edu -g 100% -u "iastate\lisa1107" -r disk:dclong=/home/$(whoami)'
alias rdesktop.lisa='rdesktop isd0jstv.card.iastate.edu -g 100% -u "iastate\lisa1107" -r disk:dclong=/home/$(whoami)'


