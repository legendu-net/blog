
# rename
alias rename.dash2underline='rename "s/-/_/g"'
alias rename.underline2dash='rename "s/-/_/g"'
alias rename.space2dash='rename "s/ /-/g"'
alias rename.space2underline='rename "s/ /_/g"'
alias rename.txt2md='rename "s/.txt$/.md/"'
alias rename.tolower='rename "y/A-Z/a-z/"'
alias rename.lcase='rename.tolower'
alias rename.toupper='rename "y/a-z/A-Z/"'
alias rename.ucase='rename.toupper'

