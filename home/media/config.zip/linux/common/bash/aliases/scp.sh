alias scp2linux11='scp2server $(whoami)@$linux11 323'
alias scp2linux10='scp2server $(whoami)@$linux10 323'
alias scp2y570='scp2server $(whoami)@$y570 323'
alias scp2econ3='scp2server lisa1107@$economics3 323'
alias scp2s07='scp2server lisa1107@$student07 323'
alias scp2s08='scp2server lisa1107@$student08 323'
alias scp2ubsas='scp2server $(whoami)@${ubsas} 22'

alias scp4linux11='scp4server $(whoami)@$linux11 323'
alias scp4linux10='scp4server $(whoami)@$linux10 323'
alias scp4y570='scp4server $(whoami)@$y570 323'
alias scp4econ3='scp4server lisa1107@$economics3 323'
alias scp4s07='scp4server lisa1107@$student07 323'
alias scp4s08='scp4server lisa1107@$student08 323'
alias scp4ubsas='scp4server $(whoami)@${ubsas} 22'


