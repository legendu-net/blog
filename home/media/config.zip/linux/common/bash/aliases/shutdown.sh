# shutdown
alias halt.1='sudo shutdown -h +1'
alias halt.2='sudo shutdown -h +2'
alias halt.3='sudo shutdown -h +3'
alias halt.4='sudo shutdown -h +4'
alias halt.5='sudo shutdown -h +5'
alias halt.10='sudo shutdown -h +10'
alias halt.20='sudo shutdown -h +20'
alias halt.30='sudo shutdown -h +30'
alias halt.60='sudo shutdown -h +60'
alias halt.120='sudo shutdown -h +120'
alias hibernate='sudo pm-hibernate'
alias suspend='sudo pm-suspend'

