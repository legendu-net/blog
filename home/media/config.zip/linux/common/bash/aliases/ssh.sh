# ssh
alias ssh.auth_sock0='export SSH_AUTH_SOCK=0'
alias ssh.l10='ssh -p 323 $(whoami)@$linux10'
alias ssh.l11='ssh -p 323 $(whoami)@$linux11'
alias ssh.i1='ssh -p 323 $(whoami)@$impact1'
alias ssh.i2='ssh -p 323 $(whoami)@$impact2'
alias ssh.i3='ssh -p 323 $(whoami)@$impact3'
alias ssh.i4='ssh -p 323 $(whoami)@$impact4'
alias ssh.y570='ssh -p 323 $(whoami)@$y570'
alias ssh.home='ssh -p 323 $(whoami)@$homeip'
alias ssh.toshiba='ssh -p 323 $(whoami)@$toshiba'
alias ssh.s07='ssh -p 22 lisa1107@$student07'
alias ssh.s08='ssh -p 22 lisa1107@$student08'
alias ssh.econ3='ssh -p 22 lisa1107@$economics3'
alias ssh.s3='ssh -p 323 root@192.168.1.5'
alias ssh.ubsas="ssh -p 22 $(whoami)@${ubsas}"

alias ssh-copy-id.linux11='ssh-copy-id -i ${HOME}/.ssh/id_rsa.pub "$(whoami)@$linux11 -p 323"'
alias ssh-copy-id.linux10='ssh-copy-id -i ${HOME}/.ssh/id_rsa.pub "$(whoami)@$linux10 -p 323"'
alias ssh-copy-id.y570='ssh-copy-id -i ${HOME}/.ssh/id_rsa.pub "$(whoami)@$y570 -p 323"'
alias ssh-copy-id.econ3='ssh-copy-id -i ${HOME}/.ssh/id_rsa.pub "lisa1107@$economics3 -p 323"'


