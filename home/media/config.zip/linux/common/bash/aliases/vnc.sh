# vnc
alias vino.start='export DISPLAY=:0.0 && /usr/lib/vino/vino-server' 
alias start.vino='vino.start'
alias vnc.y570='vncviewer $y570'
alias vnc.toshiba1='vncviewer $toshiba:1'
alias vnc.toshiba2='vncviewer $toshiba:2'
alias vnc.toshiba3='vncviewer $toshiba:3'
alias vnc.home='vncviewer $homeip'

