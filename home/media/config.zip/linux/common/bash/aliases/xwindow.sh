# lock screen 
alias xfce.lock.screen='xscreensaver-command -lock'
alias xfce.screen.lock='xscreensaver-command -lock'
alias gnome.lock.screen='gnome-screensaver-command --lock'
alias gnome.screen.lock='gnome-screensaver-command --lock'
alias xfce.logout='xfce4-session-logout'
alias xfce.logoff='xfce.logout'
alias gnome.logout='gnome-session-quit'
alias gnome.logoff='gnome.logout'

# swap keys
alias swap.caps.escape='setxkbmap -option -option caps:swapescape'

# touchpad
# disable tapping and scrolling not mouse move while typing
alias touchpad.ntwt='syndaemon -d -t -K -i 800'
# disable tapping
alias touchpad.notapping='synclient TapButton1=0'
alias touchpad.tapping='synclient TapButton1=1'


