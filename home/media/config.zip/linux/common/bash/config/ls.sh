# ls colors
eval $(dircolors -b ${config_root_dir}/linux/common/ls/dircolors.conf)

