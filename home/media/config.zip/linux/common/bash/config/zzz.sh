if [[ $(uname -n) == "y570" || $(uname -n) == "y450" || $(uname -n) == "toshiba" ]]; then
    # record ip
    /sbin/ifconfig > ${HOME}/Dropbox/ips/$(hostname)_ip.txt

    # swap Caps Lock and ESC
    swap.caps.escape

    # set vim as the default text editor
    export EDITOR=/usr/bin/vim

    if [ $RANDOM -lt 3000 ]; then
        fortune | rcowsay
    else
        report.du 
    fi
    # gnome-keyring-deamon
    # you can start this automatically ...
    # you should check if system is ubuntu ...
    export `gnome-keyring-daemon --start`
fi
