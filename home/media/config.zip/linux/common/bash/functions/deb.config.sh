#!/bin/bash
#-------------------- Config -------------------------------
function deb.config.rmdir() {
    if [ "$#" -ne 1 ]; then
        echo "Only 1 argument (base directory of configuration files) is supported."
        return 1
    fi
    if [ -e "$1" ]; then
        if [ -d "$1" ]; then
            echo "Removing directory (if empty) \"$1\" ..."
            rmdir "$1"
        else
            echo "\"$1\" is a non-directory file!"
        fi
    fi
}
function deb.config.mkdir() {
    # need 1 or 2 arguments
    # $1 the directory to be checked
    # $2 the prefix, i.e. sudo -u user
    prefix=""
    if [ "$#" -eq 2 ]; then 
        prefix="$2"
    elif [ "$#" -ne 1 ]; then
        echo "Wrong number of arguments!"
        return 1
    fi
    if [ ! -e "$1" ]; then
        echo "Creating directory \"$1\" ..."
        $prefix mkdir -p "$1"
        return 0
    fi
    if [ ! -d "$1" ]; then
        echo "A non-directory file \"$1\" exists!"
        return 1
    fi
}

function deb.config.symlink(){
    # need 2 or 3 arguments
    # $1 is source 
    # $2 is destination
    # $3 prefix of command, sudo -u user
    prefix=""
    if [ "$#" -eq 3 ]; then
        local prefix="$3"
    elif [[ "$#" -ne 2 && "$#" -ne 3 ]]; then
        echo "2 or 3 arguments are required!"
        return 1
    fi
    if [ ! -e "$1" ]; then
        echo "The source file/directory does not exist!"
        return 2
    fi
    if [ -L "$2" ]; then
        $prefix rm -rf "$2"
    elif [ -e "$2" ]; then
        echo "A non-symbolic file \"$2\" exists!"
        echo "Do you want to remove it?"
        echo "y/Y/yes/Yes/YES: Yes"
        echo "Any other: No"
        read -p "(Default yes): " remove
        remove=${remove:-yes}
        case "$remove" in
            y|Y|yes|Yes|YES)
                $prefix rm -rf "$2"
                if [ $? -eq 0 ]; then
                    echo "The non-symbolic file \"$2\" is removed."
                else
                    return 3 
                fi
                ;;
            *)
                return 3
                echo "The non-symbolic file \"$2\" is kept."
                ;;
        esac
    fi
    $prefix ln -svf "$1" "$2"
    return 0
}
function deb.config.copyfile(){
    # need 2 or 3 arguments
    # $1 is source 
    # $2 is destination
    # $3 prefix of command, sudo
    prefix=""
    if [ "$#" -eq 3 ]; then
        local prefix="$3"
    elif [[ "$#" -ne 2 || "$#" -ne 3 ]]; then
        echo "2 or 3 arguments are required!"
        return 1
    fi
    if [ ! -e "$1" ]; then
        echo "The source file/directory does not exist!"
        return 2
    fi
    if [ -L "$2" ]; then
        $prefix rm -rf "$2"
    elif [ -e "$2" ]; then
        echo "A non-symbolic file \"$2\" exists!"
        echo "Do you want to remove it?"
        echo "y/Y/yes/Yes/YES: Yes"
        echo "Any other: No"
        read -p "(Default yes): " remove
        remove=${remove:-yes}
        case "$remove" in
            y|Y|yes|Yes|YES)
                $prefix rm -rf "$2"
                echo "The non-symbolic file \"$2\" is removed."
                ;;
            *)
                return 3
                echo "The non-symbolic file \"$2\" is kept."
                ;;
        esac
    fi
    $prefix cp "$1" "$2"
    return 0
}
    
function deb.config.xfce4.usage(){
    echo "Configure the Xfce desktop environment."
    echo "Syntax: deb.config xfce4"
    echo "Create a symbolic link of a configuration directory in \"$linux_dir/common/xfce\" \
        to \"$HOME/.config/xfce4\"."
#    echo -e "Create a symbolic link of \"$linux_dir/common/xfce/menus/xfce-applications.menu\" \
#        to \"$HOME/.config/menus/xfce-applications.menu\"."
#    echo -e "Create a symbolic link of \"$linux_dir/common/xfce/applications\" \
#       \"$HOME/applications/applications\"."
}
function deb.config.xfce4(){
    echo "Configuring Xfce ..."
    local srcdir="$linux_dir/common/xfce"
    local deslink="$HOME/.config/xfce4"
    local cdirs=($(ls -d $srcdir/xfce4*))
    echo "Please select the configuration directory to use."
    local n=${#cdirs[@]}
    for ((i=0; i<$n; ++i)); do
        echo "$i: ${cdirs[$i]}"
    done
    read -p "(Default none): " cdir
    cdir=${cdir:-$n}
    cdir=${cdirs[$cdir]}
    deb.config.symlink "$cdir" "$deslink"
}

#function deb.config.xfce(){
#    echo "Configuing Xfce ..."
#    # menu 
#    local desdir="$HOME/.config/menus/"
#    deb.config.mkdir "$desdir"
#    local state=$?
#    if [ $state -eq 0 ]; then
#        deb.config.symlink "$linux_dir/common/xfce/menus/xfce-applications.menu" \
#            "$desdir/xfce-applications.menu"
#    fi
#    local desdir="$HOME/.local/share/"
#    deb.config.mkdir "$desdir"
#    local state=$?
#    if [ $state -eq 0 ]; then
#        deb.config.symlink "$linux_dir/common/xfce/applications/" \
#            "$desdir/applications"
#    fi
#    # panel
#    local desdir="$HOME/.config/xfce4/"
#    deb.config.mkdir "$desdir"
#    local state=$?
#    if [ $state -eq 0 ]; then
#        deb.config.symlink "$linux_dir/common/xfce/panel/" "$desdir/panel"
#    fi
#    echo "Done."
#}

#function deb.config.mimeapps(){
#    echo "Configuring mimeapps ..."
#    state=deb.config.mkdir "$HOME/.local/share/applications"
#    # mimeapps.list
#    ln -svf $1/mimeapps/mimeapps.list $HOME/.local/share/applications/
#    echo "Done."
#}

function deb.config.matlab(){
    echo "Configuring Matlab ..."
    local srcdir="/usr/local/MATLAB/"
    local state=$?
    if [ $state -eq 0 ]; then
        subdirs=$(find "$srcdir" -mindepth 1 -maxdepth 1 -not -empty -type d)
        n=$(echo "$subdirs" | wc -l)
        if [ $n -gt 1 ]; then
            echo "Multiple versions of Matlab exist. Please type in the one that you want to link."
            ls "$srcdir" | echo
            read version
            local desdir="/usr/bin/"
            deb.config.mkdir "$desdir" sudo
            local state=$?
            if [ $state -eq 0 ]; then
                deb.config.symlink "$srcdir/$version/bin/matlab" \
                "$desdir/matlab" sudo 
            fi
        else
            if [ $n -eq 1 ]; then
                local desdir="/usr/bin/"
                deb.config.mkdir "$desdir" sudo
                local state=$?
                if [ $state -eq 0 ]; then
                    deb.config.symlink "$subdirs/bin/matlab" \
                        "$desdir/matlab" sudo 
                fi
            else
                echo "Matlab is not installed (to the default location). \
                    Please configure it manually."
            fi
        fi
    fi
    echo "Done."
}

function deb.config.matlab.usage(){
    echo "Configure MATLAB."
    echo "Syntax: deb.config matlab"
    echo "Make a symbolic link of MATLAB executable (installed in /usr/local/) to /usr/bin/matlab." 
}
function deb.config.remmina(){
    echo "Configuring Remmina ..."
    local srcdir="$linux_dir/common/remmina" 
    local desdir="$HOME/.remmina"
    deb.config.symlink "$srcdir" "$desdir"
}
function deb.config.remmina.usage(){
    echo "Configure Remmina."
    echo "Syntax: deb.config.remmina"
    echo "Make a symbolic link of \"$linux_dir/common/remmina\" to \"$HOME/.remmina\"."
}


#function deb.config.eclipse(){
#    echo "Configuring Eclipse ..."
#    if [ -f /usr/local/eclipse/eclipse ]; then
        # $prefix ln -svf /usr/local/eclipse/eclipse /usr/bin/eclipse
#    fi
#}

function deb.config.shell.usage(){
    echo "Configure shell script."
    echo "Syntax: deb.config shell."
    echo -e "Make a symbolic link of \"$linux_dir/common/bash/bash.sh\" \
        to \"$HOME/.bashrc\"."
}

function deb.config.shell(){
    echo "Configuring shell script ..."
    desfile="$HOME/.bashrc"
    srcfile="$bash_dir/bashrc"
    if [ -f "$desfile" ]; then
        mv "$desfile" "${srcfile}.bak"
    fi
    deb.config.symlink "$srcfile" "$desfile"
    echo "Done."
}

function deb.config.dictionary.usage(){
    echo "Configure dictionary database."
    echo "Syntax: deb.config dictionary"
    echo -e "Make a symbolic link of \"$linux_dir/common/dictionary\" \
        to \"$HOME/.dictionary\"."
}
function deb.config.dictionary(){
    echo "Configuring dictionary ..."
    # links
    deb.config.symlink "$linux_dir/common/dictionary" "$HOME/.dictionary"
    echo "Done."
}
function deb.config.fuse.usage(){
    echo "Configure fuse."
    echo "Syntax: deb.config fuse"
    echo "Add user to fuse."
}
function deb.config.fuse(){
    user=$(whoami)
    if [ $# -ge 0 ]; then
        user=$@
    fi
    sudo adduser $user fuse
    newgrp fuse
    echo "Logout and then login or reboot if group permission is not in effect."
}

function deb.config.ssh.usage(){
    echo "Configure SSH."
    echo "Syntax: deb.config ssh"
    echo -e "Create symbolic link of \"$linux_dir/common/ssh/ssh_config\" \
        to \"/etc/ssh/ssh_config/ssh_config\"." 
    echo -e "Create symbolic link of \"$linux_dir/common/ssh/sshd_config\" \
        to \"/etc/sshd_config/sshd_config\"."
}
function deb.config.sshs(){
    echo "Configuring SSH server ..."
    local desfile="/etc/ssh/sshd_config"
    local srcfile="$linux_dir/common/ssh/sshd_config"
    if [ -f "$desfile" ]; then
        cp "$desfile" "${srcfile}.bak"
    fi
    deb.config.copyfile "$srcfile" "$desfile" sudo
    sudo chmod 644 "$desfile"
    echo "Done."
}
function deb.config.sshc(){
    echo "Configuring SSH ..."
    local desdir="$HOME/.ssh"
    local srcdir="$linux_dir/common/ssh"
    deb.config.mkdir "$desdir" 
    local state=$?
    if [ $state -eq 0 ]; then
        deb.config.symlink "$srcdir/ssh_config" "$desdir/config"
        deb.config.symlink "$srcdir/known_hosts" "$desdir/known_hosts"
        deb.config.symlink "$srcdir/authorized_keys" "$desdir/authorized_keys"
    fi
    echo "Done."
}

function deb.config.xdg.usage(){
    echo "Configure xdg."
    echo "Syntax: deb.config xdg"
    echo -e "Create symbolic link of \"$linux_dir/common/xdg/user-dirs.conf\" \
        to \"$HOME/.config/user-dirs.conf\"."
    echo -e "Create symbolic link of \"$linux_dir/common/xdg/user-dirs.defaults\" \
        to \"$HOME/.config/user-dirs.defaults\"."
    echo -e "Create symbolic link of \"$linux_dir/common/xdg/user-dirs.dirs\" \
        to \"$HOME/.config/user-dirs.dirs\"."
    echo "Create $HOME/archives if not exists."
    echo "Remove $HOME/Desktop if exists."
    echo "Remove $HOME/Documents if exists."
    echo "Remove $HOME/Music if exists."
    echo "Remove $HOME/Public if exists."
    echo "Remove $HOME/Templates if exists."
    echo "Remove $HOME/Videos if exists."
}

function deb.config.xdg(){
    echo "Configuring xdg ..."
    local desdir="$HOME/.config"
    deb.config.mkdir "$desdir"
    local state=$?
    if [ $state -eq 0 ]; then
        deb.config.symlink "$linux_dir/common/xdg/user-dirs.conf" \
            "$desdir/user-dirs.conf"
        deb.config.symlink "$linux_dir/common/xdg/user-dirs.defaults" \
            "$desdir/user-dirs.defaults"
        deb.config.symlink "$linux_dir/common/xdg/user-dirs.dirs" \
            "$desdir/user-dirs.dirs"
    fi
    # remove directoris
    deb.config.rmdir "$HOME/Desktop"
    deb.config.rmdir "$HOME/Documents"
    deb.config.rmdir "$HOME/Music"
    deb.config.rmdir "$HOME/Public"
    deb.config.rmdir "$HOME/Pictures"
    deb.config.rmdir "$HOME/Templates"
    deb.config.rmdir "$HOME/Videos"
    if [ -d "$HOME/Downloads" ]; then
        mv "$HOME/Downloads" "$HOME/downloads"
    fi
    deb.config.mkdir "$HOME/archives"
    echo "Done."
}

function deb.config.vim.usage(){
    echo "Configure vim."
    echo "Syntax: deb.config vim"
    echo -e "Make a symbolic link of \"$linux_dir/common/vim/vimrc\" \
        to \"$HOME/.vimrc\"."
    echo -e "Make a symbolic link of \"$linux_dir/common/vim/colors\" \
        to \"$HOME/.vim/colors\"."
}
function deb.config.vim(){
    echo "Configuring Vim ..."
    desfile="$HOME/.vimrc"
    srcfile="$linux_dir/common/vim/vimrc"
    if [ -f "$desfile" ]; then
        cp "$desfile" "${srcfile}.bak"
    fi
    deb.config.symlink "$srcfile" "$desfile"
    local desdir="$HOME/.vim"
    deb.config.mkdir "$desdir"
    local state=$?
    if [ $state -eq 0 ]; then
        deb.config.symlink "$linux_dir/common/vim/colors" "$desdir/colors"
    fi
    echo "Done."
}

function deb.config.git.usage(){
    echo "Configure git."
    echo "Syntax: deb.config git"
    echo "Make a symbolic link of \"$linux_dir/common/git/gitconfig\" \
        to \"$HOME/.gitconfig\"."
    echo "Make a symbolic link of \"$linux_dir/common/git/gitignore\" \
        to \"$HOME/.gitignore\"."
}
function deb.config.git(){
    echo "Configuring Git ..."
    # configuration
    deb.config.symlink "$linux_dir/common/git/gitconfig" "$HOME/.gitconfig"
    deb.config.symlink "$linux_dir/common/git/gitignore" "$HOME/.gitignore"
    echo "Done."
}

function deb.config.fonts.usage(){
    echo "Configure fonts."
    echo "Syntax: deb.config fonts"
    echo "Make a symbolic link of \"$linux_dir/common/fonts\" \
        to \"$HOME/.fonts\"."
}
function deb.config.fonts(){
    echo "Configuring fonts ..."
    # configuration
    deb.config.symlink "$linux_dir/common/fonts" "$HOME/.fonts"
    echo "Refreshing fonts ..."
    fc-cache
    echo "Done."
}

function deb.config.juliastudio.usage(){
    echo "Configure juliastudio."
    echo "Syntax: deb.config juliastudio"
    echo "Make a symbolic link of \"$linux_dir/common/fonts\" \
        to \"$HOME/.fonts\"."
}
function deb.config.juliastudio() {
    echo "Configuring JuliaStudio ..."
    # symbolic links
    local desfile="/usr/bin/jstudio"
    local srcfile="/usr/local/julia-studio/bin/JuliaStudio"
    deb.config.symlink "$srcfile" "$desfile" sudo
}

#function deb.config.zotero.usage(){
#    echo "Configure zotero."
#    echo "Syntax: deb.config zotero"
#    echo "Make a symbolic link of zotero (installed in /usr/local/) to /usr/bin/zotero."
#}

#function deb.config.zotero() {
#    echo "Configuring Zotero ..."
#    # symbolic links
#    local desdir="/usr/bin/"
#    local srcdir="/usr/local/zotero/"
#    deb.config.symlink "${srcdir}zotero" "${desdir}zotero" sudo
#    deb.config.symlink "${srcdir}run-zotero.sh" "${desdir}run-zotero" sudo
#}

function deb.config.r.usage(){
    echo "Configure r."
    echo "Syntax: deb.config r"
    echo "Make a symbolic link of \"$linux_dir/common/r/Renviron\" \
        to \"$HOME/.Renviron\"."
    echo "Make a symbolic link of \"$linux_dir/common/r/Rprofile.site\" \
        to \"$HOME/.Rprofile\"."
    echo "Make a symbolic link of \"$linux_dir/common/r/Makevars\" \
        to \"$HOME/Makevars\"."
    echo "Create $HOME/.R/library/ if not exists."
}
function deb.config.r(){
    echo "Configuring R ..."
    # setup links
    deb.config.symlink "$linux_dir/common/r/Renviron" "$HOME/.Renviron"
    deb.config.symlink "$linux_dir/common/r/Rprofile.site" "$HOME/.Rprofile"
    #ln -svf $1/r/Rhistory $HOME/.Rhistory
    desdir="$HOME/.R" # must capitalize
    deb.config.mkdir "$desdir"
    local state=$?
    if [ $state -eq 0 ]; then 
        # deb.config.symlink "$linux_dir/common/r/Makevars" "$desdir/Makevars"
        deb.config.mkdir "$desdir/library"
    fi
    echo "Done."
}

#function deb.config.copy() {
#    echo "Configuring the cloud sync service Copy ..."
#    # symbolic link
#    local desdir="/usr/bin/"
#    local srcdir="/usr/local/copy/"
#    if [ $(getconf LONG_BIT) -eq 32 ]; then
#        srcdir="${srcdir}x86/"
#    else
#        srcdir="${srcdir}x86_64/"
#    fi
#    deb.config.symlink "${srcdir}CopyAgent" "${desdir}copyagent" sudo
#    deb.config.symlink "${srcdir}CopyCmd" "${desdir}copycmd" sudo
#    deb.config.symlink "${srcdir}CopyConsole" "${desdir}copyconsole" sudo
#}

function deb.config.thunderbird.usage(){
    echo "Configure thunderbird."
    echo "Syntax: deb.config thunderbird"
    echo "Make a symbolic link of thunderbird (installed in /usr/local/) to /usr/bin/thunderbird."
}
function deb.config.thunderbird(){
    echo "Configuring thunderbird ..."
    # symbolic link
    desfile="/usr/bin/thunderbird"
    srcfile="/opt/thunderbird/thunderbird"
    deb.config.symlink "$srcfile" "$desfile" sudo
    echo "Done."
}

function deb.config.firefox.usage(){
    echo "Configure firefox."
    echo "Syntax: deb.config firefox"
    echo "Make a symbolic link of firefox (installed in /usr/local/) to /usr/bin/firefox"
}
function deb.config.btsync(){
    echo "Configuring btsync ..."
    # symbolic link
    local desfile=/usr/bin/btsync
    local srcfile=/opt/btsync/btsync
    deb.config.symlink $srcfile $desfile sudo
}
function deb.config.firefox(){
    echo "Configuring firefox ..."
    # symbolic link
    desfile=/usr/bin/firefox
    srcfile=/opt/firefox/firefox
    deb.config.symlink "$srcfile" "$desfile" sudo
    # desktop file
    desktop=/tmp/firefox.desktop
    echo "[Desktop Entry]" > $desktop
    echo "Encoding=UTF-8" >> $desktop
    echo "Name=Firefox" >> $desktop
    echo "Comment=Run Firefox" >> $desktop
    echo "Exec=/usr/bin/firefox" >> $desktop
    echo "TryExec=/opt/firefox/firefox" >> $desktop
    echo "StartupNotify=true" >> $desktop
    echo "Terminal=false" >> $desktop
    echo "Type=Application" >> $desktop
    echo "Icon=$linux_dir/common/firefox/mozicon128.png" >> $desktop
    echo "GenericName=Web Browser" >> $desktop
    echo "Categories=Application;Network" >> $desktop
    # move to /usr/share/applications
    mv $desktop /usr/share/applications/
    echo "firefox.desktop added into /usr/share/applications/"
    echo "Done."
}
function deb.config.texlive.usage(){
    echo "Configure texlive."
    echo "Syntax: deb.config texlive"
    echo "Make a symbolic link of firefox (installed in /usr/local/) to /usr/bin/firefox"
    echo "Make a symbolic link of \"$linux_dir/common/texlive/ctex-xecjk-winfonts.def\" \
        to \"/usr/share/texlive/texmf-dist/tex/latex/ctex/fontset/ctex-xecjk-winfonts.def\"."
}
function deb.config.texlive(){
    echo "Configuring texlive ..."
    local desdir="/usr/share/texlive/texmf-dist/tex/latex/ctex/fontset/"
    deb.config.mkdir "$desdir"
    local state=$?
    if [ $state -eq 0 ]; then
        deb.config.symlink "$linux_dir/common/texlive/ctex-xecjk-winfonts.def" \
            "$desdir/ctex-xecjk-winfonts.def"
    fi
    echo "Done."
}

#function deb.config.jabref.usage(){
#    echo "Configure JabRef."
#    echo "Syntax: deb.config jabref"
#    echo "Make a symbolic link of \"$linux_dir/common/jabref/prefs.xml\"\
#        to \"$HOME/.java/.userPrefs/net/sf/jabref\"."
#}

#function deb.config.jabref() {
#    echo "Configuring jabref ..."
#    local desdir="$HOME/.java/.userPrefs/net/sf/jabref"
#    deb.config.mkdir "$desdir"
#    local state=$?
#    if [ $state -eq 0 ]; then
#        deb.config.symlink "$linux_dir/common/jabref/prefs.xml" "$desdir/prefs.xml"
#    fi
#    echo "Done."
#}

function deb.config.vbill.usage(){
    echo "Configure vbill"
    echo "Syntax: deb.config jabref"
    echo "Make a symbolic link of \"$linux_dir/common/jabref/prefs.xml\"\
        to \"$HOME/.java/.userPrefs/net/sf/jabref\"."
}

function deb.config.vbill(){
    echo "Configuring verizon bill ..."
    desfile="/usr/bin/vbill"
    srcfile="$ruby_dir/verizon/vbill.rb"
    deb.config.symlink "$srcfile" "$desfile" sudo 
}

function deb.config.tmux.usage(){
    echo "Configure tmux."
    echo "Syntax: deb.config jabref"
    echo "Make a symbolic link of \"$linux_dir/common/jabref/prefs.xml\"\
        to \"$HOME/.java/.userPrefs/net/sf/jabref\"."
}

function deb.config.tmux() {
    echo "Configuring tmux ..."
    deb.config.symlink "$linux_dir/common/tmux/tmux.conf" "$HOME/.tmux.conf"
    echo "Done."
}

function deb.config.terminator.usage(){
    echo "Configure terminator."
    echo "Syntax: deb.config jabref"
    echo "Make a symbolic link of \"$linux_dir/common/jabref/prefs.xml\"\
        to \"$HOME/.java/.userPrefs/net/sf/jabref\"."
}

function deb.config.terminator(){
    echo "Configuring terminator ..."
    local desdir="$HOME/.config/terminator/"
    deb.config.mkdir "$desdir"
    local state=$?
    if [ $state -eq 0 ]; then
        deb.config.symlink "$linux_dir/common/terminator/config" "$desdir/config"
    fi
}

function deb.config.terminal.usage(){
    echo "Configure terminal."
    echo "Syntax: deb.config jabref"
    echo "Make a symbolic link of \"$linux_dir/common/jabref/prefs.xml\"\
        to \"$HOME/.java/.userPrefs/net/sf/jabref\"."
}

function deb.config.terminal() {
    echo "Configuring terminal ..."
    local desdir="$HOME/.config/Terminal/"
    deb.config.mkdir "$desdir"
    local state=$?
    if [ $state -eq 0 ]; then
        deb.config.symlink "$linux_dir/common/terminal/terminalrc" "$desdir/terminalrc"
    fi
}
function deb.config.tcpd.usage(){
    echo "Configure tcpd."
    echo "Syntax: deb.config tcpd"
    echo "Make a symbolic link of \"$linux_dir/common/jabref/prefs.xml\"\
        to \"$HOME/.java/.userPrefs/net/sf/jabref\"."
}

function deb.config.tcpd() {
    echo "Configuring tcpd ..."
    desfile="/etc/hosts.allow"
    srcfile="$linux_dir/common/tcpd/hosts.allow"
    if [ -f "$desfile" ]; then
        cp "$desfile" "${srcfile}.bak"
    fi
    deb.config.copyfile "$srcfile" "$desfile" sudo
    sudo chmod 644 "$desfile" 
}


#function deb.config.synctime(){
#    echo "Configruing time synchronization ..."
#    local desdir="/etc/cron.weekly"
#    deb.config.symlink "$linux_dir/common/system/sync_time" "$desdir/sync_time"
#    echo "Done."
#}

function deb.config.synaptics(){
    echo "Configuring touchpad ..."
    desdir="/etc/X11/xorg.conf.d"
    desfile="$desdir/10-synaptics.conf"
    srcfile="$linux_dir/common/synaptics/10-synaptics.conf"
    deb.config.mkdir "$desdir" sudo
    local state=$?
    if [ $state -eq 0 ]; then
        if [ -f "$desfile" ]; then
            cp "$desfile" "${srcfile}.bak"
        fi
        deb.config.copyfile "$srcfile" "$desfile" sudo
        sudo chmod 644 "$desfile"
    fi
}


#function deb.config.postfix(){
#    echo "Configuring postfix ..."
#    local desdir="/etc/postfix/"
#    deb.config.mkdir "$desdir"
#    local state=$?
#    if [ $state -eq 0 ]; then
#        deb.config.symlink "$linux_dir/common/postfix/main.cf" "$desdir/main.cf"
#        deb.config.symlink "$linux_dir/common/postfix/sasl_passwd" "$desdir/sasl_passwd"
#        deb.config.symlink "$linux_dir/common/postfix/sasl_passwd.db" "$desdir/sasl_passwd.db"
#    fi
#    echo "Done."
#}


function deb.config.network(){
    echo "Configuing network ..."
    local desdir="/etc/network/"
    deb.config.mkdir "$desdir"
    local state=$?
    if [ $state -eq 0 ]; then
        deb.config.copyfile "$linux_dir/common/network/interfaces" "$desdir/interfaces" sudo
    fi
    echo "Done."
}


#function deb.config.mixer(){
#    echo "Configuring mixer ..."
#    local desdir="$HOME/.config/xfce4/xfconf/xfce-perchannel-xml"
#    deb.config.mkdir "$HOME"
#    local state=$?
#    if [ $state -eq 0 ]; then
#        deb.config.symlink "$linux_dir/common/xfce/xfce-perchannel-xml/xfce4-mixer.xml" "$desdir/xfce4-mixer.xml"
#    fi
#}


function deb.config.blog.usage(){
    echo "Configure blog."
    echo "Create symbolic link \"$python_dir/blog/epost.py\" to \"/usr/bin/epost\"."
}
function deb.config.notes.usage(){
    echo "Configure notes."
    echo "Create symbolic link \"$python_dir/notes/notes.py\" to \"/usr/bin/notes\"."
}
function deb.config.notes(){
    echo "Configuring notes ..."
    deb.config.symlink "$python_dir/notes/notes.py" "/usr/bin/notes" sudo
#    deb.config.symlink "$python_dir/blog/eheader.py" "/usr/bin/eheader" sudo
}
function deb.config.blog(){
    echo "Configuring blog ..."
    deb.config.symlink "$python_dir/blog/epost.py" "/usr/bin/epost" sudo
#    deb.config.symlink "$python_dir/blog/eheader.py" "/usr/bin/eheader" sudo
}
function deb.config.unison(){
    echo "Configuring unison ..."
    local desdir="$HOME/.unison"
    local desfile="$desdir/default.prf"
    local srcfile="$linux_dir/common/unison/default.prf"
    deb.config.mkdir "$desdir" 
    local state=$?
    if [ $state -eq 0 ]; then
        deb.config_symlink "$srcfile" "$desfile" 
    fi
    echo "Done."
}
function deb.config.autostart() {
    # need 1 argument
    # $1 the name of the autostart configuration to be linked into $HOME/.config/autostart
    echo "Configuring auto start programs ..."
    local desdir="$HOME/.config/"
    deb.config.mkdir "$desdir"
    local state=$?
    if [ $state -eq 0 ]; then
        deb.config.symlink "$linux_dir/common/autostart/$1" "$desdir/autostart/$1"
    fi
}
function deb.reconfig(){
    deb.config.shell
    deb.config.sshc
    deb.config.git
    deb.config.vim
    deb.config.terminator
    deb.config.r
    deb.config.remmina
    deb.config.xfce4
    deb.config.xdg
    deb.config.fonts
    deb.config.icedove
    deb.config.blog
    deb.config.tcpd
}
function deb.reconfig.usage(){
    echo "Reconfigure a Debian series Linux distribution."
    echo "Shell, Git, Vim and R are reconfigured."
}
function deb.config.usage(){
    if [ $# -eq 1 ]; then
        echo "Configure installed packages."
        echo "Syntax: deb.config package"
        echo "To get help use: deb.config -h package"
        echo "Supported package configuration includes:"
        echo "r: deb.config -h r"
        echo "git: deb.config -h git" 
    else
       deb.config.$2.usage 
    fi
}
function deb.config(){
    # need to write a function return all keywords, 
    # and check whether $1 is in the keywords, ...
    if [ "$1" == "-h" ]; then
        deb.config.usage $@
    else
        deb.config.$1
    fi
}
if [ "$0" == ${BASH_SOURCE[0]} ]; then
    deb.config $@
fi
