#!/bin/bash
#------------------ Install -------------------------------
function deb.install.server(){
    apt-get install sudo wajig vim openssh-client openssh-server screen tmux 
    deb.config.ssh
}
function deb.install.dbms(){
    wajig install mysql-server mysql-workbench sqlite3 mongodb
}
function deb.install.finance(){
    wajig install gnucash
}
function deb.install.speedup.usage(){
    echo "Installs packages (readahead, localepurge, bootchart and preload) that speeds up Debian."
    echo "Syntax: deb.install.speedup"
}
function deb.install.speedup(){
    wajig install -y readahead localepurge bootchart preload
}
function deb.install.terminator(){
    wajig install -y terminator
    deb.config.terminator
}
function deb.install.media.usage(){
    echo "Installs some multimedia related tools including vlc, ffmpeg, tesseract-ocr, gocr, imagemagic, gwenview and pdftk."
    echo "Syntax: deb.install.media"
}
function deb.install.media(){
    wajig install -y vlc ffmpeg tesseract-ocr gocr imagemagick gwenview pdftk
}
function deb.install.archive(){
    wajig install -y unzip zip rar unrar p7zip tar dtrx xarchiver
}
function deb.install.archive.usage(){
    echo "Installs archive tools (tar, unzip, zip, rar, unrar, p7zip and dtrx)"
    echo "Syntax: deb.install.archive"
}
function deb.install.chinese(){
    deb.install.ibus
    deb.install.fonts
}
function deb.install.editor.usage(){
    echo "Installs some popular editors including vim, eclipse, textstudio and gedit."
    echo "Syntax: deb.install.editor"
}
function deb.install.editor(){
    deb.install.vim
    deb.install.gedit
    wajig install -y eclipse texstudio 
}
function deb.install.postfix(){
    wajig install -y postfix
}
function deb.install.sshfs(){
    wajig install -y sshfs 
    deb.config.fuse
}
function deb.install.entertainment.usage(){
    echo "Installs fortune and cowsay."
    echo "Syntax: deb.install.entertainment"
}
function deb.install.entertainment(){
    wajig install -y fortune cowsay
}
function deb.install.network(){
    # ask which wireless manager to use
    echo "Which network manager do you want to install?"
    echo "1: network-manager-gnome"
    echo "2: wicd"
    echo "Any other key: none of them"
    read -p "(Default 1): " nm
    nm=${nm:-1} 
    case "$nm" in
        "1")
            nm=network-manager-gnome
            ;;
        "2")
            nm=wicd
            ;;
        *)
            nm=""
            ;;
    esac
    wajig install -y $nm arp-scan
}
function deb.install.de(){
    # ask which desktop manager to use
    echo "Which desktop manager do you want to install?"
    echo "1: lightdm"
    echo "2: gdm3"
    echo "3: kdm"
    echo "Any other key: none of them"
    read -p "(Default 1): " dm
    dm=${dm:-1}
    case "$dm" in
        "1")
            dm=lightdm
            ;;
        "2")
            dm=gdm3
            ;;
        "3")
            dm=kdm
            ;;
        *)
            dm=""
            ;;
    esac
    wajig install -y $dm
}
function deb.install.xfce4(){
    wajig install -y xfce4 xfce4-datetime-plugin xfce4-battery-plugin 
    deb.install.de
    deb.install.network
    deb.config.xfce4 
}
function deb.install.texlive(){
    # install minimum texlive and some extra fonts
    wajig install -y texlive texlive-latex-extra texlive-fonts-extra \
        texlive-lang-cjk texlive-xetex texstudio
}
function deb.install.vim(){
    # install vim
    wajig install -y vim-nox 
    deb.config.vim
}
function deb.install.python(){
    wajig install -y ipython3 ipython3-notebook
}
function deb.install.git(){
    # install git
    wajig install -y git
    deb.config.git
}
function deb.install.fonts.usage(){
    echo 'Install some fonts (mostly chinese related) including: ttf-arphic-uming, ttf-wqy-microhei, ttf-wqy-zenhei, xfonts-wqy and fonts-sil-abyssinica.'
    echo 'You can also installing existing (via symbolic link) fonts using deb.config.fonts.'
    echo 'Syntax: deb.install.fonts'
}
# chinese fonts
function deb.install.fonts(){
    wajig install -y ttf-arphic-uming ttf-wqy-microhei ttf-wqy-zenhei \
        xfonts-wqy fonts-sil-abyssinica
    deb.config.fonts
}
function deb.install.r(){
    # install r
    wajig install -y r-base-dev # rstudio 
    deb.config.r
}
# install tools needed to build .deb packages
function deb.install.deb(){
    wajig install -y build-essential autoconf automake libtool pkg-config intltool checkinstall
}
function deb.install.sshc(){
    wajig install -y openssh-client 
    deb.config.sshc
}
function deb.install.sshs(){
    wajig install -y openssh-server fail2ban
    deb.config.sshs
}
function deb.install.java.usage(){
    echo "Installs JDK, icedtea-netx and icedtea-plugin."
    echo "Syntax: deb.install.java"
}
function deb.intall.java(){
    wajig install -y default-jdk icedtea-netx icedtea-plugin
}
function deb.install.julia(){
    wajig install -y julia # julia-studio
}
function deb.install.ibus(){
    # install ibus
    wajig install -y ibus ibus-sunpinyin
}
function deb.install.gedit(){
    wajig install -y gedit
    # deb.config.gedit
}
function deb.install.dict.usage(){
    echo "Installs some useful dictionaries (databases include: dict-gcide, dict-devil, dict-jargon, dict-xdict and dict-stardic)"
    echo "Syntax: deb.install.dict"
}
function deb.install.dict(){
    wajig install -y dict dict-gcide dict-devil dict-jargon dict-xdict dict-stardic
}
function deb.install.unison(){
    wajig install -y unison
    deb.config.unison
}
function deb.install.iceweasel(){
    wajig install -y iceweasel flashplugin-nonfree
}
function deb.install.btsync(){
    filename=$(basename "$1")
    extension="${filename##*.}"
    if [ $extension == "bz2" ]; then
        option=-jxvf
    elif [ $extension == "gz" ]; then
        option=-zxvf
    else
        echo "Unrecognized installation file!."
        return 1
    fi
    local desdir=/opt/btsync
    deb.config.mkdir $desdir sudo
    echo "Uncompressing files into \"$desdir\" ..."
    sudo tar $option $1 -C $desdir
    deb.config.btsync
}
#' install firefox from a local tar.gz file
function deb.install.firefox(){
    filename=$(basename "$1")
    extension="${filename##*.}"
    if [ $extension == "bz2" ]; then
        option=-jxvf
    elif [ $extension == "gz" ]; then
        option=-zxvf
    else
        echo "Unrecognized installation file!."
        return 1
    fi
    tar $option $1 -C /opt/
    wajig purge -y iceweasel
    wajig install -y flashplugin-nonfree
    deb.config.firefox
}

if [ "$0" == ${BASH_SOURCE[0]} ]; then
    deb.install $@
fi
