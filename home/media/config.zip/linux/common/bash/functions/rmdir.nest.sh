
function rmdir.nest(){
    # get content
    sub=$(ls "$1")
    if [ $sub == "" ]; then
        rmdir "$1"
        return 0
    fi
    for e in $(ls "$1"); do
        if [ -d "$e" ]; then
            rmdir.nest "$e"
        fi
    done
    rmdir "$1"
}

