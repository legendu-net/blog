#!/bin/bash
# TODO make this more powerful, up k levels
# more robust about error and so on
function script.name.usage(){
    echo "Get the name of script."
    echo "Syntax: script.name arg1 arg2"
}
function script.name(){
    local p=$(readlink -f ${BASH_SOURCE[0]})
    while [ $(basename ${p}) != "$1" ]; do
        p=$(dirname ${p})
        if [ ${p} == "$2" ]; then
            echo "$2"
            return 1
        fi
    done
    echo ${p}
}
if [ "$0" == ${BASH_SOURCE[0]} ]; then
    script.name $@
fi
