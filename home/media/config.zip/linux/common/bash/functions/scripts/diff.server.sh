#!/bin/bash
# compare a remote text file with a local text file using ssh
# need 4 arguments
# $1: server name
# $2: port number
# $3: remote text file name
# $4: local text file name
# This function is mainly for the simplicity of creating aliases.
ssh -p $2 $1 cat "$2" | diff "$3" -

