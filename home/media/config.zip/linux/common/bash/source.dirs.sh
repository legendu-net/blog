
#' TODO add options to exclude files
function source.dir.usage(){
    echo "Source in all shell script (files end with .sh) in a directory."
    echo "Syntax: source.dir dir"
}

function source.dir(){
    if [ "$1" == "-h" ]; then
        source.dir.usage
        return 0
    fi
    for f in ${1}/*.sh; do
        source $f
    done
}

bash_dir=$(dirname $(readlink -f ${BASH_SOURCE[0]}))
source.dir ${bash_dir}/functions
source.dir ${bash_dir}/aliases
source.dir ${bash_dir}/config
