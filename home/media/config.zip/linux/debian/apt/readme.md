You'd better not use the preferences, 
because it make some packages unavalible to you. 
I'm not very sure about the exactly reason.
