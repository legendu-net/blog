
function deb.config.respository.usage(){
    echo "Configure apt-get source repository."
    echo "Syntax: deb.config aptget"
    echo -e "Make a symbolic link of \"$debian_dir/apt/sources.list\" \
        to /etc/apt/sources.list."
}
function deb.config.repository() {
    echo "Configuring apt-get ..."
    echo "Which sources.list do you want to use?"
    echo "1: testing"
    echo "2: unstable"
    echo "Any other: stable"
    read -p "(Default 1): " sl
    sl=${sl:-1}
    case "$sl" in
        1)
            sl=$debian_dir/apt/testing
            ;;
        2)
            sl=$debian_dir/apt/unstable
            ;;
        *)
            sl=$debian_dir/apt/stable
            ;;
    esac
    desfile="/etc/apt/sources.list"
    if [ -f "$desfile" ]; then
        cp "$desfile" "$debian_dir/apt/sources.list"
    fi
    deb.config.copyfile "$sl" "$desfile" sudo
    sudo chmod 644 "$desfile"
    # deb.config.symlink "$1/apt/preferences" "/etc/apt/preferences"
    echo "Done."
}
function deb.config.icedove(){
    echo "Configuring Icedove ..."
    local desdir="$HOME/.icedove"
    local srcdir="$debian_dir/icedove"
    deb.config.symlink "$srcdir" "$desdir"
}

function deb.config.autostart.setxkbmap() {
    echo "Configuring auto start programs ..."
    local desdir="$HOME/.config/"
    deb.config.mkdir "$desdir"
    local state=$?
    if [ $state -eq 0 ]; then
        deb.config.symlink "$linux_dir/common/autostart/setxkbmap.desktop" \
            "$desdir/autostart/setxkbmap.desktop"
    fi
}

#function deb.config.autostart.glxdock(){
#    echo "Configuring auto start programs ..."
#    local desdir="$HOME/.config/"
#    deb.config.mkdir "$desdir"
#    local state=$?
#    if [ $state -eq 0 ]; then
#        deb.config.symlink "$linux_dir/common/autostart/glx-dock.desktop" "$desdir/autostart/glx-dock.desktop"
#    fi
#}
