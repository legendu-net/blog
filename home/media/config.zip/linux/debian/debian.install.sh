
# it's hightly recommended to install 0-3 for daily desktop use
function deb.install.0(){
    # make home directory safe
    chmod 700 $HOME
    # ask which sources.list to use
    echo "Which sources.list do you want to use?"
    echo "1: testing"
    echo "2: unstable"
    echo "Any other: stable"
    read -p "(Default 1): " sl
    sl=${sl:-1}
    case "$sl" in
        1)
            sl=${debian_dir}/apt/testing
            ;;
        2)
            sl=${debian_dir}/apt/unstable
            ;;
        *)
            sl=${debian_dir}/apt/stable
            ;;
    esac
    su -c "cp \"$sl\" /etc/apt/sources.list && \
        chmod 644 /etc/apt/sources.list && \
        echo -e \"\nThe unstable source is copied to /etc/apt/sources.list.\n\" && \
        apt-get -y update && apt-get upgrade && \
        echo -e \"\nSystem is updated successfully.\n\" && \
        apt-get -y install -y wajig sudo && \
        echo -e \"\nwajig and sudo are installed.\n\" && \
        adduser $(whoami) sudo && \
        echo -e \"\n$(whoami) is added to the sudo group.\n\""
    newgrp sudo
    echo "Logout and then login or reboot if group permission is not in effect." && sync 
}
function deb.install.0.usage(){
    echo -e "Configures repository.\n\
        Installs wajig and sudo.\n\
        Configures sudo.\n"
}
function deb.install.1.usage(){
    echo -e "Installs apt-file, vim, openssh-client and git.\n\
        Packages are automatically configured if necessary and possible."
}
function deb.install.1(){
    wajig install -y apt-file 
    deb.install.vim
    deb.install.sshc
    deb.install.git
}

function deb.install.2.usage(){
    echo -e "Installs xfce, terminator, gedit, keepassx, evince, tmux and screen.\n\
        Packages are automatically configured if necessary and possible."
}
function deb.install.2(){
    deb.install.xfce
    wajig install -y keepassx evince tmux screen xarchiver remmina rdesktop 
    deb.install.gedit
    deb.install.terminator
}
function deb.install.3.usage(){
    echo -e "Installs wget, curl, rsync, unision, openssh-server and sshfs\n\
        Packages are automatically configured if necessary and possible."
}
function deb.install.3(){
    wajig install -y wget curl rsync 
    deb.install.sshfs
    deb.install.unison
    deb.install.sshs
}
function deb.install.4.usage(){
    echo -e "Installs abiword, gnumeric, nautilus-dropbox, cairo-dock, software-center and chinese fonts.\n\
        Packages are automatically configured if necessary and possible."
}
function deb.install.4(){
    wajig install -y nautilus-dropbox cairo-dock software-center abiword gnumeric  
    deb.install.chinese
}
function deb.install.5.usage(){
    echo -e "Installs R and Julia.\n\
        Packages are automatically configured if necessary and possible."
}
function deb.install.5(){
    deb.install.r
    deb.install.julia
    # deb.install.texlive
}
function deb.install.6.usage(){
echo -e "Installs archive tools (zip, rar, drtx, etc.) and media tools (see deb.install.media.usage for details).\n\
            Packages are automatically configured if necessary and possible."
}
function deb.install.6(){
    deb.install.archive
    deb.install.media
}
function deb.install.7.usage(){
    echo -e "Installs virtualbox and transmission.\n\
            Packages are automatically configured if necessary and possible."
}
function deb.install.7(){
    wajig install -y virtualbox transmission
    deb.install.editor
}
