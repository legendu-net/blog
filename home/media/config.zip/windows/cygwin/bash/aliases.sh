# define some paths
export cdrive='/cygdrive/c'
export ddrive='/cygdrive/d'
export udrive='/cygdrive/u'
export gdrive='/cygdrive/g'
export winhome="${cdrive}/Users/$(whoami)"
export projects="${winhome}/projects"
export downloads="${winhome}/Downloads"
export documents="${winhome}/Documents"
export trash_dir="${cdrive}/\\\$Recycle.Bin"
export gshare="${gdrive}/PORT_RISK_MGMT_95360"
export backup_dir="${udrive}/backup"
export github_dir="${udrive}/github"
# trash
alias trash="mv -bt ${trash_dir}"

# rsync
alias rsync.projects="rsync -ah ${projects}/ ${backup_dir}/projects/"

# cd & ls
alias ls.c='ls /cygdrive/c'
alias cs.c='cs /cygdrive/c'
alias ls.d='ls /cygdrive/d'
alias cs.d='cs /cygdrive/d'
alias ls.e='ls /cygdrive/e'
alias cs.e='cs /cygdrive/e'
alias ls.f='ls /cygdrive/f'
alias cs.f='cs /cygdrive/f'
alias ls.g='ls /cygdrive/g'
alias cs.g='cs /cygdrive/g'
alias ls.u='ls /cygdrive/u'
alias cs.u='cs /cygdrive/u'
alias cd.home='cd /cygdrive/c/Users/$(whoami)'
alias cs.home='cs /cygdrive/c/Users/$(whoami)'
alias cd.projects='cd ${projects}'
alias cs.projects='cs ${projects}'
alias cs.learn='cs ${projects}/learn'
alias cd.learn='cd ${projects}/learn'
alias cs.www='cs /cygdrive/c/inetpub/wwwroot/'
alias cd.documents='cd ${documents}'
alias cs.documents='cs ${documents}'
alias cd.downloads="cd ${downloads}"
alias cs.downloads="cs ${downloads}"

# shutdown
alias halt.0='shutdown -h now'
alias halt.1='shutdown -h +1'
alias halt.2='shutdown -h +2'
alias halt.3='shutdown -h +3'
alias halt.4='shutdown -h +4'
alias halt.5='shutdown -h +5'
alias halt.10='shutdown -h +10'
alias halt.15='shutdown -h +15'
alias halt.20='shutdown -h +20'
alias halt.25='shutdown -h +25'
alias halt.30='shutdown -h +30'
alias halt.40='shutdown -h +40'
alias halt.50='shutdown -h +50'
alias halt.60='shutdown -h +60'
alias halt.120='shutdown -h +120'

# vim
alias vim.aliases="vim ${config_root_dir}/windows/cygwin/bash/aliases.sh"
