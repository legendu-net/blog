
echo.green "Configuring Vim ..."
# settings
dclong.config.create_link "$config_root_dir/linux/debian/vim/vimrc" "${HOME}/.vimrc"
local desdir="${HOME}/.vim"
dclong.config.check_dir "${desdir}"
local state=$?
if [ $state -eq 0 ]; then
    dclong.config.create_link "$config_root_dir/linux/debian/vim/colors" "${desdir}/colors"
fi
echo.green "Done."
return 0
